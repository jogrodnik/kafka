`incubator/docker-registry` is deprecated in favor of `stable/docker-registry`

Note: `incubator/docker-registry` was previously moved from `incubator` to `stable` before a deprecated version was published to this helm repo. Therefore, in order to remove the old versions from aggregators such as [Helm Hub](https://hub.helm.sh) and [Artifact Hub](https://artifacthub.io/) we have re-added this placeholder deprecated chart. See https://github.com/helm/charts/issues/23128 for further details.
