`incubator/gocd` is deprecated in favor of the `stable/gocd`.

Note: this chart was previously moved from `incubator` to `stable` before a deprecated version was published to this helm repo. Therefore, in order to remove the old versions from aggregators such as [Helm Hub](https://hub.helm.sh) and [Artifact Hub](https://artifacthub.io/) we have re-added this placeholder deprecated chart. See https://github.com/helm/charts/issues/23128 for further details.
