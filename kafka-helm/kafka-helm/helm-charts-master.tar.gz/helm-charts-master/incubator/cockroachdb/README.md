This Helm chart is deprecated

Given the `incubator` repo [deprecation timeline](https://github.com/helm/charts#deprecation-timeline), future CockroachDB Helm charts are now located at [cockroachdb/charts](https://github.com/cockroachdb/helm-charts/).

The CockroachDB charts repository is already included in the Hubs. Updated installation instructions are included in the new source code repository [README](https://github.com/cockroachdb/helm-charts/blob/master/README.md).

Note: `incubator/cockroachdb` was moved from `incubator` to `stable` before a deprecated version was published to this helm repo. Therefore, in order to remove the old versions from aggregators such as [Helm Hub](https://hub.helm.sh) and [Artifact Hub](https://artifacthub.io/) we have re-added this placeholder deprecated chart. See https://github.com/helm/charts/issues/23128 for further details.
