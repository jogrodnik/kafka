`incubator/consul` is deprecated

Use HashiCorp's [Official Helm Chart](https://github.com/hashicorp/consul-helm), which is already included in the Hubs. See [Consul docs](https://www.consul.io/docs/k8s/installation/overview) for installation instructions.

Note: `incubator/consul` was previously moved from `incubator` to `stable` before a deprecated version was published to this helm repo. Therefore, in order to remove the old versions from aggregators such as [Helm Hub](https://hub.helm.sh) and [Artifact Hub](https://artifacthub.io/) we have re-added this placeholder deprecated chart. See https://github.com/helm/charts/issues/23128 for further details.
